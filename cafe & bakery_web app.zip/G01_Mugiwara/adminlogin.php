<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Welcome Comrade</title>
  </head>
  <body>
    <?php
      $dbServername = "localhost";
      $dbUsername = "root";
      $dbPassword = "#e#KTEad%JPy8eYSCqd";
      $dbName = "coffeedtest";

      $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
      if(isset($_POST['adminName'])){
      $adminName = stripslashes($_REQUEST["adminName"]);
      $adminName = mysqli_real_escape_string($conn, $adminName);
      $adminPassword = stripslashes($_REQUEST["adminPassword"]);
      $adminPassword = mysqli_real_escape_string($conn, $adminPassword);

      $sql = "SELECT * FROM MyAdmin WHERE adminName = '$adminName' AND adminPassword = '$adminPassword'";
      $result = mysqli_query($conn, $sql) or die("Connection failed: " . mysqli_error($conn));
      $rows = mysqli_num_rows($result);
      if($rows == 1){
        $_SESSION['adminName'] = $adminName;
        header("Location: adminlogin.php");
      }
      else{
        echo "<div class='form'>
        <h3>Username/Password is Incorrect</h3>
        <br/>Click here to <a href='adminlogin.php'>Login</a> again</div>";
      }
    }
    else{
    ?>
    <div class="login">
      <h1>Login</h1>
      <form class="" action="" method="post">
        <input type="text" name="adminName" placeholder="Name">
        <br>
        <input type="password" name="adminPassword" placeholder="Password">
        <br>
        <input type="submit" name="submit" value="login">
      </form>
    </div>
  <?php } ?>
  </body>
</html>
