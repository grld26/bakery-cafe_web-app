<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Register Now</title>
    <link rel="stylesheet" href="userstyle.css?v=<?php echo time(); ?>">
    <script type="text/javascript">
      function signUp(){
        var name = document.forms["RegForm"]["fullname"];
        var mobile = document.forms["RegForm"]["mobile"];
        var email = document.forms["RegForm"]["email"];
        var password = document.forms["RegForm"]["password"];

        if(name.value == ""){
          window.alert("Please enter your name");
          name.focus();
          return false;
        }

        if(mobile.value == ""){
          window.alert("Please enter your mobile");
          mobile.focus();
          return false;
        }

        if(email.value == ""){
          window.alert("Please enter your email");
          email.focus();
          return false;
        }

        if(password.value == ""){
          window.alert("Please enter your password");
          password.focus();
          return false;
        }
      }
    </script>
    <style media="screen">
      .form{
        margin: 0 auto;
        width: 420px;
        margin-left: -10px;
      }

      .heading1{
        text-align: center;
      }

      .msh{
        text-align: center;
      }

    </style>
    <script src="myformm.js"></script>
  </head>
  <body class="bod">
    <?php
      $dbServername = "localhost";
      $dbUsername = "root";
      $dbPassword = "#e#KTEad%JPy8eYSCqd";
      $dbName = "coffeedtest";

      $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
      if(isset($_REQUEST["fullname"])){
        $fullname = stripslashes($_REQUEST["fullname"]);
        $fullname = mysqli_real_escape_string($conn, $fullname);
        $mobile = stripslashes($_REQUEST["mobile"]);
        $mobile = mysqli_real_escape_string($conn, $mobile);
        $email = stripslashes($_REQUEST["email"]);
        $email = mysqli_real_escape_string($conn, $email);
        $password = stripslashes($_REQUEST["password"]);
        $password = mysqli_real_escape_string($conn, $password);

        $sql = "INSERT INTO CoffeedUser(user_name, user_mobile, user_email, user_pwd) VALUES('$fullname', '$mobile', '$email', '$password')";
        $result = mysqli_query($conn, $sql);
        if($result){
          echo "<div class='msh'>
          <h3>Registered succesfully</h3>
          <br/>Click here to <a href='signIn.php'>Login</a></div>";
        }
      }
      else{
    ?>
<div class="out">
<div class="containerX">
  <div class="header">
    <h2> USER ACCOUNT REGISTRATION</h2>
  </div>
  <form id="form" class="form" method ="post" action="" onsubmit="return signUp()" name="RegForm">
    <div class="form-control">
      <label for="first">FULL NAME</label>
      <input type="text" placeholder="Enter your full name" id="fullname" class ="changeUppercase" name="fullname"/>
      <i class="fas fa-check-circle"></i>
      <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
    </div>
    <div class="form-control">
      <label for="mobile">MOBILE</label>
      <input type="tel" placeholder="(+60)123456789" id="mobile" name="mobile" minlength="10">
      <i class="fas fa-check-circle"></i>
      <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
    </div>
    <div class="form-control">
      <label for="email">EMAIL</label>
      <input type="email" placeholder="Enter your email address" id="email" name="email"/>
      <i class="fas fa-check-circle"></i>
      <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
    </div>
    <div class="form-control">
      <label for="password">PASSWORD</label>
      <input type="password" name="password" placeholder="Enter your password" id="password" pattern="(?=^\S*$)(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,6}"/>
      <i class="fas fa-check-circle"></i>
      <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
    </div>

    <div class ="togglepass">

    <input type="checkbox" onclick="myFunction()">Show Password

            <script>
                    function myFunction() {
                    var x = document.getElementById("password");
                        if (x.type === "password") {
                            x.type = "text";
                        } else {
                            x.type = "password";
                        }
                    }
            </script>
    </div>

    <p class="gnd">
      <label for="gen">GENDER</label></br>
      <label id="male">Male</label>
      <input type='radio' name='radioBtn' required id="male">
      <label id="female">Female</label>
      <input type='radio' name='radioBtn' required id="female">
    </p>

    <p class="end">
    <button type="submit" >Register</button>
    <button type="reset">Clear</button>
    </p>
        <p class ="userlogin">Already a member? <a href="signIn.php">Log In</a></p>
  </form>
</div>
</div>

  <?php } ?>
  </body>
</html>
