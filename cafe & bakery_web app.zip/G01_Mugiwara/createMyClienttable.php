<?php
  $servername = "localhost";
  $username = "root";
  $password = "#e#KTEad%JPy8eYSCqd";
  $dbname = "coffeedtest";

  $conn = mysqli_connect($servername, $username, $password, $dbname);

  if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
  }

  $sql = "CREATE TABLE MyClient(
    clientID INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(30) NOT NULL,
    lastName VARCHAR(30) NOT NULL,
    mobileNumber BIGINT NOT NULL,
    emailAddress VARCHAR(50) NOT NULL,
    homeAddress VARCHAR(256) NOT NULL
  )";

  if(mysqli_query($conn, $sql)){
    echo "Table MyClient created successfully";
  }
  else{
    echo "Error creating table: " . mysqli_error($conn);
  }

  mysqli_close($conn);
 ?>
