<?php
  $servername = "localhost";
  $username = "root";
  $password = "#e#KTEad%JPy8eYSCqd";
  $dbname = "coffeedtest";

  $conn = mysqli_connect($servername, $username, $password, $dbname);

  if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
  }

  $sql = "CREATE TABLE CoffeedUser(
    user_id INT(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    user_first VARCHAR(256) NOT NULL,
    user_last VARCHAR(256) NOT NULL,
    user_email VARCHAR(256) NOT NULL,
    user_mobile BIGINT NOT NULL,
    user_pwd VARCHAR(245) NOT NULL,
    user_gender VARCHAR(256) NOT NULL
  )";

  if(mysqli_query($conn, $sql)){
    echo "Table CoffeedUser created successfully";
  }
  else{
    echo "Error creating table: " . mysqli_error($conn);
  }

  mysqli_close($conn);
?>
