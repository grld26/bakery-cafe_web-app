<?php

$adminName = $_POST['adminName'];
$adminPassword = $_POST['adminPassword'];

  $servername = "localhost";
  $username = "root";
  $password = "#e#KTEad%JPy8eYSCqd";
  $dbname = "coffeedtest";

  $conn = mysqli_connect($servername, $username, $password, $dbname);

  if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
  }



  $query = mysqli_query($conn, "SELECT * FROM MyAdmin WHERE adminName = '$adminName' AND adminPassword = '$adminPassword'");

  $rows = mysqli_num_rows($query);
  if($rows == 1){
    header("Location: invoice.php");
  }
  else{
    $error = "Username/Password is invalid ;(";
  }

  mysqli_close($conn);

 ?>
