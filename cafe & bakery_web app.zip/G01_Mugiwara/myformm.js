const form = document.getElementById('form');
const first = document.getElementById('first');
const last = document.getElementById('last');
const email = document.getElementById('email');
const phone = document.getElementById('phone');
const password = document.getElementById('password');
const password2 = document.getElementById('password2');

form.addEventListener('submit', e => {
	e.preventDefault();
	
	checkInputs();
});

function checkInputs() {
	// trim to remove the whitespaces
	const firstValue = first.value.trim();
	const lastValue = last.value.trim();
	const emailValue = email.value.trim();
	const phoneValue = phone.value.trim();
	const passwordValue = password.value.trim();
	const password2Value = password2.value.trim();
	
	if(firstValue === '') {
		setErrorFor(first, 'First name cannot be blank');
	} else {
		setSuccessFor(first);
	}
	if(lastValue === '') {
		setErrorFor(last, 'Last name cannot be blank');
	} else {
		setSuccessFor(last);
	}
	
	if(emailValue === '') {
		setErrorFor(email, 'Email cannot be blank');
	} else if (!isEmail(emailValue)) {
		setErrorFor(email, 'Not a valid email');
	} else {
		setSuccessFor(email);
	}

	if(phoneValue === '') {
		setErrorFor(phone, 'Not a valid phone number');
	} else {
		setSuccessFor(phone);
	}
	
	if(passwordValue === '') {
		setErrorFor(password, 'Password cannot be blank');
	} else {
		setSuccessFor(password);
	}
	
	if(password2Value === '') {
		setErrorFor(password2, 'Password cannot be blank');
	} else if(passwordValue !== password2Value) {
		setErrorFor(password2, 'Passwords does not match');
	} else{
		setSuccessFor(password2);
	}
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.className = 'form-control error';
	small.innerText = message;
}

function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.className = 'form-control success';
}

	
function isEmail(email) {
	return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
}


//extra functions
function Validatefname(firstValue){
    
    var Firstletter = /^[A-Z]/
    if(firstValue.value.match(Firstletter)){
        return true;
    }
    else {
        alert("First Name: First letter must be an Uppercase");
        firstValue.focus();
        return false;
    }
}

function Validatelname(lastValue){
    
    var Lastletter = /^[A-Z]/
    if(lastValue.value.match(Lastletter)){
        return true;
    }
    else {
        alert("Last Name: First letter must be an Uppercase");
        lastValue.focus();
        return false;
    }
}

function allnumeric(phone){
	return /^[0-9]+$/.test(phone);
}

function ValidatePass(password){
    
    var validpassw = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{1,6}.\S$/;    //6 characters long, No Space, at least ONE Uppercase, at least ONE Lowercase, at least ONE special character, number

    if(password.value.match(validpassw)){
        return true;
    }
    
    else { 
    
        alert('Password: must contain at least ONE Uppercase, ONE Lowercase, One Special Character, 6 characters long, NO SPACE!');
        password.focus();
        return false;
    }
}


function ValidateConfpass (password2, password){     //comparing the original pass with confirm pass

    if(password2.value == password.value){
        return true;
    }

    else{
        alert("Confirm Password: Password does not match! Try again!");
        password2.focus();
        return false;
    }
}


function genderselect(ugender){

    if(ugender.value == "gender"){
        alert("Gender: Please select a gender");
        return false;
    }

    else{
        return true;
    }
}



function ClearForm(){    //this function will be executed when user click on the 'Clear' button
    alert("Form cleared!");
}



















