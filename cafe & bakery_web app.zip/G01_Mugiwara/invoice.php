<?php

  $servername = "localhost";
  $username = "root";
  $password = "#e#KTEad%JPy8eYSCqd";
  $dbname = "coffeedtest";

  $conn = mysqli_connect($servername, $username, $password, $dbName);
  $sql = "SELECT * FROM Invoice WHERE '".$_GET['invoiceID']"'";
  $invoice = msqli_fetch_array($sql);

  require('fpdf17/fpdf.php');

  $pdf = new FPDF('p', 'mm', 'A4');
  $pdf -> AddPage();

  $pdf -> SetFont('Arial', 'B', 14);
  $pdf -> Cell(130, 5, 'Coffeed SDN BHD', 0, 0);
  $pdf -> Cell(59, 5, 'Invoice', 0, 1);

  $pdf -> SetFont('Arial', '', 11);

  $pdf -> Cell(130, 5, '[Street Address]', 0, 0);
  $pdf -> Cell(59, 5, '', 0, 1);

  $pdf -> Cell(130, 5, '[City, Country, Zip]', 0, 0);
  $pdf -> Cell(25, 5, 'Date', 0, 0);
  $pdf -> Cell(34, 5, '[dd/mm/yyyy]', 0, 1);

  $pdf -> Cell(130, 5, 'Phone [+085 1234567]', 0, 0);
  $pdf -> Cell(25, 5, 'Invoice #', 0, 0);
  $pdf -> Cell(34, 5, $invoice['invoiceID'], 0, 1);

  $pdf -> Cell(130, 5, 'Fax [+123456789]', 0, 1);

  $pdf -> Cell(189, 10, '', 0, 1);

  $pdf -> Cell(100, 5, 'Delivery To:', 0, 1);

  $pdf -> Cell(10, 5, '', 0, 0);
  $pdf -> Cell(90, 5, $invoice['fullName'], 0, 1);

  $pdf -> Cell(10, 5, '', 0, 0);
  $pdf -> Cell(90, 5, '<<NULL>>', 0, 1);

  $pdf -> Cell(10, 5, '', 0, 0);
  $pdf -> Cell(90, 5, $invoice['homeAddress'], 0, 1);

  $pdf -> Cell(10, 5, '', 0, 0);
  $pdf -> Cell(90, 5, $invoice['mobileNumber'], 0, 1);

  $pdf -> Cell(189, 10, '', 0, 1);

  $pdf -> SetFont('Arial', 'B', 12);

  $pdf -> Cell(130, 5, 'Item', 1, 0);
  $pdf -> Cell(25, 5, 'Quantity', 1, 0);
  $pdf -> Cell(34, 5, 'Amount', 1, 1);

  $pdf -> SetFont('Arial', '', 11);

  $pdf -> Cell(130, 5, $invoice['itemName'], 1, 0);
  $pdf -> Cell(25, 5, $invoice['invoiceID'], 1, 0);
  $pdf -> Cell(34, 5, $invoice['grandTotal'], 1, 1, 'R');

  $pdf -> Cell(189, 10, '', 0, 1);

  $pdf -> SetFont('Arial', 'B', 11);
  $pdf -> Cell(130, 5, '', 0, 0);
  $pdf -> Cell(25, 5, 'Subtotal', 1, 0);
  $pdf -> SetFont('Arial', '', 11);
  $pdf -> Cell(8, 5, 'RM', 1, 0);
  $pdf -> Cell(26, 5, $invoice['grandTotal'], 1, 1, 'R');

  $pdf -> SetFont('Arial', 'B', 11);
  $pdf -> Cell(130, 5, '', 0, 0);
  $pdf -> Cell(25, 5, 'Delivery Fee', 1, 0);
  $pdf -> SetFont('Arial', '', 11);
  $pdf -> Cell(8, 5, 'RM', 1, 0);
  $pdf -> Cell(26, 5, '0', 1, 1, 'R');

  $pdf -> SetFont('Arial', 'B', 11);
  $pdf -> Cell(130, 5, '', 0, 0);
  $pdf -> Cell(25, 5, 'Service Tax', 1, 0);
  $pdf -> SetFont('Arial', '', 11);
  $pdf -> Cell(8, 5, 'RM', 1, 0);
  $pdf -> Cell(26, 5, '0', 1, 1, 'R');

  $pdf -> SetFont('Arial', 'B', 11);
  $pdf -> Cell(130, 5, '', 0, 0);
  $pdf -> Cell(25, 5, 'Total', 1, 0);
  $pdf -> SetFont('Arial', '', 11);
  $pdf -> Cell(8, 5, 'RM', 1, 0);
  $pdf -> Cell(26, 5, $receipt['grandTotal'], 1, 1, 'R');

  $pdf -> Cell(189, 10, '', 0, 1);
  $pdf -> Cell(189, 10, '', 0, 1);
  $pdf -> Cell(189, 10, '', 0, 1);
  $pdf -> Cell(189, 10, '', 0, 1);
  $pdf -> Cell(189, 10, '', 0, 1);

  $pdf -> SetFont('Arial', 'I', 8);
  $pdf -> Cell(130, 5, 'THANK YOU & HAVE A NICE DAY ;)', 0, 0, '[align center]');

  $pdf -> Output();
 ?>
