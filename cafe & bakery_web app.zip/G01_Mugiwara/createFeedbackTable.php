<?php
  $servername = "localhost";
  $username = "root";
  $password = "#e#KTEad%JPy8eYSCqd";
  $dbname = "coffeedtest";

  $conn = mysqli_connect($servername, $username, $password, $dbname);

  if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
  }

  $sql = "CREATE TABLE Feedback(
    feedbackID INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    feedemail VARCHAR(256) NOT NULL,
    feedmsg VARCHAR(256) NOT NULL
  )";

  if(mysqli_query($conn, $sql)){
    echo "Table Feedback created successfully";
  }
  else{
    echo "Error creating table: " . mysqli_error($conn);
  }

  mysqli_close($conn);
 ?>
