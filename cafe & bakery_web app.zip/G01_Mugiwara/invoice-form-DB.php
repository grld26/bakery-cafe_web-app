<?php
  $servername = "localhost";
  $username = "root";
  $password = "#e#KTEad%JPy8eYSCqd";
  $dbname = "myDB";

  $conn = new mysqli($servername,$username,$password,$dbname);
  if($conn->connect_error){
    die("Connection Failed: " . $conn->connect_error);
  }
 ?>

 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>Invoice Generator</title>
   </head>
   <body>
     <button type="button" name="print-invoice" id="print">Print Invoice (PDF)</button>
   </body>
 </html>
