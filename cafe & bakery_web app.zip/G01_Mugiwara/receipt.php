<html>
    <head>
        <title>Reciept</title>
    </head>
    <body>
        <div class="root">
            <div class="logo">
                <img src="assests/logo/Coffeed.png" alt="Coffeed-logo"/>
            </div>
            <div class="receipt-body">
                <h2>Muhyiddin bin Hj. Mohammad Yassin</h2>
                <div class="row">
                    <div class="col-xs-7">
                        <table class="table-receipt-order-detail">
                            <tbody>
                                <tr>
                                    <th>
                                        Nombor Pesanan:
                                    </th>
                                </tr>
                                <tr>
                                    <td>
                                        299-12/01/2021-93206
                                    </td>
                                </tr>
                                <tr>
                                    <th>Tarikh/Masa Pesanan:</th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>