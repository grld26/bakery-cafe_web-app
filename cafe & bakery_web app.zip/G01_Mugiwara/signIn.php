<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login Now</title>
    <link rel="stylesheet" href="userstyle.css?v=<?php echo time(); ?>">
  </head>
  <body class="bod">
    <script src="myformm.js"></script>
    <?php
      $dbServername = "localhost";
      $dbUsername = "root";
      $dbPassword = "#e#KTEad%JPy8eYSCqd";
      $dbName = "coffeedtest";

      $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
      if(isset($_POST['fullname'])){
        $fullname = stripslashes($_REQUEST["fullname"]);
        $fullname = mysqli_real_escape_string($conn, $fullname);
        $password = stripslashes($_REQUEST["password"]);
        $password = mysqli_real_escape_string($conn, $password);
        $sql = "SELECT * FROM CoffeedUser WHERE user_name = '$fullname' AND user_pwd = '$password'";
        $result = mysqli_query($conn, $sql) or die("Connection failed: " . mysqli_error($conn));
        $rows = mysqli_num_rows($result);
        if($rows == 1){
          $_SESSION['fullname'] = $fullname;
          header("Location: index.html");
        }
        else{
          echo "<div class='form'>
          <h3>Username/Password is Incorrect</h3>
          <br/>Click here to <a href='signIn.php'>Login</a></div>";
        }
      }
      else{
        ?>
<div class="container2">
  <div class="header">
    <h2> USER ACCOUNT LOG IN</h2>
  </div>
  <form id="form" class="form" method ="post" action="">
    <div class="form-control">

      <label for="fullname">FULL NAME</label>
      <input type="text" placeholder="Enter your full name" id="fullname" class ="changeUppercase" name="fullname"/>
      <i class="fas fa-check-circle"></i>
      <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
    </div>

    <div class="form-control">
      <label for="password">PASSWORD</label>
      <input name="password" type="password" placeholder="Enter your password" id="password" pattern="(?=^\S*$)(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,6}"/>
      <i class="fas fa-check-circle"></i>
      <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
    </div>

    <p class="end">
    <button type="submit" >Log in</button>
    </p>

        <p class ="usersignup">Not a member yet? <a href="signUp.php">Sign Up</a></p>
  </form>

</div>
      <?php } ?>
  </body>
</html>
