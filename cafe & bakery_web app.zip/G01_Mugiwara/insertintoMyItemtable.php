<?php
  $servername = "localhost";
  $username = "root";
  $password = "#e#KTEad%JPy8eYSCqd";
  $dbname = "coffeedtest";

  $conn = mysqli_connect($servername, $username, $password, $dbname);
  if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
  }

  $sql = "INSERT INTO MyItem(
    itemName, itemPrice)
    VALUES('Croissant', 3.00);";

    $sql .= "INSERT INTO MyItem(
      itemName, itemPrice)
      VALUES('Assorted Buns', 4.00);";

      $sql .= "INSERT INTO MyItem(
        itemName, itemPrice)
        VALUES('Hot Cross Bun', 6.00);";

        $sql .= "INSERT INTO MyItem(
          itemName, itemPrice)
          VALUES('Assorted Donuts 12s', 16.00);";

          $sql .= "INSERT INTO MyItem(
            itemName, itemPrice)
            VALUES('Waffle', 5.00);";

            $sql .= "INSERT INTO MyItem(
              itemName, itemPrice)
              VALUES('Portuguese Tart', 3.00);";

              $sql .= "INSERT INTO MyItem(
                itemName, itemPrice)
                VALUES('Coffeed Popeye Burger', 11.00);";

                $sql .= "INSERT INTO MyItem(
                  itemName, itemPrice)
                  VALUES('Fried Chicken Wrap', 8.00);";

                  $sql .= "INSERT INTO MyItem(
                    itemName, itemPrice)
                    VALUES('Lamb Flatbread with Secret Sauce', 8.00);";

                    $sql .= "INSERT INTO MyItem(
                      itemName, itemPrice)
                      VALUES('Chocolate Chip Cookies', 2.00);";

                      $sql .= "INSERT INTO MyItem(
                        itemName, itemPrice)
                        VALUES('Strawberry Ice-cream Cake', 8.00);";

                        $sql .= "INSERT INTO MyItem(
                          itemName, itemPrice)
                          VALUES('Cherry Puff', 4.00);";

                          $sql .= "INSERT INTO MyItem(
                            itemName, itemPrice)
                            VALUES('Vanilla Berries Puff', 6.00);";

                            $sql .= "INSERT INTO MyItem(
                              itemName, itemPrice)
                              VALUES('Glazed Rose Apple Puff', 6.00);";

                              $sql .= "INSERT INTO MyItem(
                                itemName, itemPrice)
                                VALUES('Coffeed Banana Cake', 12.00);";

                                $sql .= "INSERT INTO MyItem(
                                  itemName, itemPrice)
                                  VALUES('Chocolate Cake', 14.00);";

                                  $sql .= "INSERT INTO MyItem(
                                    itemName, itemPrice)
                                    VALUES('Red Velvet Cake', 16.00);";

                                    $sql .= "INSERT INTO MyItem(
                                      itemName, itemPrice)
                                      VALUES('Americano', 8.00);";

                                      $sql .= "INSERT INTO MyItem(
                                        itemName, itemPrice)
                                        VALUES('Cappucino', 12.00);";

                                        $sql .= "INSERT INTO MyItem(
                                          itemName, itemPrice)
                                          VALUES('Latte', 11.00);";

                                          $sql .= "INSERT INTO MyItem(
                                            itemName, itemPrice)
                                            VALUES('Matcha Latte', 14.00);";

                                            $sql .= "INSERT INTO MyItem(
                                              itemName, itemPrice)
                                              VALUES('Iced Caramel Machiato', 14.00);";

                                              $sql .= "INSERT INTO MyItem(
                                                itemName, itemPrice)
                                                VALUES('Iced Frappucino', 14.00);";

                                                $sql .= "INSERT INTO MyItem(
                                                  itemName, itemPrice)
                                                  VALUES('Chamomile Tea', 10.00);";

                                                  $sql .= "INSERT INTO MyItem(
                                                    itemName, itemPrice)
                                                    VALUES('Hot Chocolate', 10.00)";

  if(mysqli_multi_query($conn, $sql)){
    echo "New records created successfully";
  }
  else{
    "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

  mysqli_close($conn);
 ?>
