<?php
  $servername = "localhost";
  $username = "root";
  $password = "#e#KTEad%JPy8eYSCqd";
  $dbname = "coffeedtest";

  $conn = mysqli_connect($servername, $username, $password, $dbname);
  if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
  }

  $sql = "INSERT INTO MyAdmin(
    adminName, adminPassword)
    VALUES('Peter', 'takiyagenjeh47'
  )";

  if(mysqli_query($conn, $sql)){
    echo "New record created successfully";
  }
  else{
    "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

  mysqli_close($conn);
 ?>
