<!DOCTYPE html>
<html>
<head>
	<title>Feedback</title>
    <link rel="stylesheet" href="main.css">
    <!--Internal stylings-->
    <style type="text/css">

    body{
      font-family: monospace;
      color: #E6D6B6;
      background: #211108;
    }

    :root{
      --hoverr: #D5AB67;
      --name: #E6D6B6;
      --orderbutton: #81441F;
      --transition: all 0.4s ease;
    }

    .alright{
      background-color: transparent;
      width: 700px;
      margin-left: 350px;
      margin-top: -40px;
    }

    .s{
      width: 670px;
      height: 30px;
      margin-top: -10px;
      margin-bottom: 20px;
    }

    .t{
      margin-top: 5px;
      float: left;
    }
    </style>

		<!-- Javascript form validation -->
		<script type="text/javascript">
			function feedback(){
				var email = document.forms["feedback"]["email"];
				var message = document.forms["feedback"]["message"];

				if(email.value == ""){
          window.alert("Please enter your email");
          email.focus();
          return false;
        }

        if(message.value == ""){
          window.alert("Please enter your message");
          message.focus();
          return false;
			}
		}
		</script>
</head>

<body>

  <?php
    $dbServername = "localhost";
    $dbUsername = "root";
    $dbPassword = "#e#KTEad%JPy8eYSCqd";
    $dbName = "coffeedtest";

    $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
    if(isset($_REQUEST["email"])){
    $email = stripslashes($_REQUEST["email"]);
    $email = mysqli_real_escape_string($conn, $email);
    $message = stripslashes($_REQUEST["message"]);
    $message = mysqli_real_escape_string($conn, $message);

    $sql = "INSERT INTO Feedback(feedemail, feedmsg) VALUES('$email', '$message')";
    $result = mysqli_query($conn, $sql);
    if($result){
        echo "<div class='form'>
        <h3>Sent!</h3>
        <br/>Click here to go<a href='feedbackform.php'>back</a></div>";
      }
    }
    else{
      ?>
      <!--Header image-->
      <div class="headerimage">
        <img src="resources/2.jpeg">
      </div>
      <!--End of header image-->

      <!--Navigation bar-->
      <div class="navbar">
        <a href="index.html"> Home</a>
      <div class="dropdown">
        <button class="dropbtn"> Our Menu</button>
          <div class="dropdown-content">
             <a href="menu1.html"> All-Time Favourites</a>
             <a href="menu2.html"> Specials</a>
             <a href="menu3.html"> Cakes</a>
             <a href="menu4.html"> Beverages</a>
          </div>
      </div>
            <a href="order.html"> Order Now</a>
            <a href="feedback.html"> Feedback</a>
            <a href="contact.html"> Contact Us</a>
            <a href=""> Log In</a>
      </div>
      <!--End of navigation bar-->

        <!--Page header for feedback page-->
        <div class = "padding-y menu" id = "menu">
          <div class = "container">
            <div class = "title">
              <h2> Feedback</h2>
                <div class = "line center">
                <div></div>
                <div></div>
              </div>
            </div>
          </div>
        </div>
        <!--End of page header -->

        <!--Feedback form section-->
        <div class="alright columns">
          <h3 style="margin-bottom: 40px; margin-top: -15px;"> Customer Feedback Form</h3>
        <div class="products">

            <form id="form" class="form" method="post", onsubmit="return feedback()" name="feedback">
            <div>
                <label style="font-size: 15px; font-family: inherit; font-weight: bold;">EMAIL</label>
                <p><input class="s" type="text" placeholder="Enter your email address" name="email"/></p>
            </div>
            <div>
                <label style="font-size: 15px; font-family: inherit; font-weight: bold;"> MESSAGE</label>
                <p class="t"><textarea style="width: 670px; height: 70px;" name="message" type="text"></textarea></p>
            </div>
              <p>
                <a href=""><button class="butn check" style="margin-top: 15px;" type="submit" name="submit"> Send Feedback</button></a>
              </p>
            </form>
        </div>
        </div>
        <!--End of feedback form-->
        <?php
    }
    ?>
</body>
<footer>
    <div class="footer">
        <h2> &#169 MUGIWARA 2021</h2>
    </div>
</footer>
</html>
