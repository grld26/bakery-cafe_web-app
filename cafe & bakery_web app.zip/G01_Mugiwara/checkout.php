<!DOCTYPE html>
<html>
<head>
	<title>
		Checkout
	</title>
    <link rel="stylesheet" href="main.css?v=<?php echo time(); ?>">
    <style type="text/css">

    body{
        font-family: monospace;
        color: #E6D6B6;
        background: #211108;
    }

    :root{
      --hoverr: #D5AB67;
        --name: #E6D6B6;
        --orderbutton: #81441F;
        --transition: all 0.4s ease;
    }

    button{
        cursor: pointer;
    }

    .a, .b, .c, .d{
        width: 635px;
        margin-top: -12px;
    }

    .e{
        margin-top: -12px;
    }

    .tc{
        margin-top: 20px;
    }

    .form-control{
        margin-top: 20px;
        font-weight: bold;
        font-size: 16px;
    }

    .gnd{
        margin-top: 30px;
        font-weight: bold;
        font-size: 16px;
    }

    .row{
        margin-top: -56px;
    }

    .alright {
    position: relative;
    width: 66.66667%;
    box-shadow: 0 0 5px #DDD;
    height: 700px;
    }

    .columns{
        padding: 15px;
    }

    .products{
        float: left;
    }

    .cartcolumn{
        width: 300px;
    }

    .cart{
      box-shadow: 0 0 5px #DDD;
      padding: 15px;
      overflow: auto;
    }

    .butn, .butn2{
      background-color: #81441F;
      font-family: monospace;
    }

    .button22{
        margin-top: 25px;
        font-weight: bold;
    }


    </style>
		<!--Javascripts used to aid the functions of the page-->
		     <script type="text/template" id="shpcart">
		        <% _.each(items, function (item) { %> <div class = "shopcart"> <h4> <%= item.name %> </h4>  <span class="label">
		        <%= item.count %> item<% if(item.count > 1)
		        {%>s
		        <%}%> for RM<%= item.total %></span ></div>
		        <% }); %>
		    </script>

		<script src="order.js"></script>
		<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
		<script src='https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.5.2/underscore-min.js'></script>
</head>

<body>

  <?php
    $dbServername = "localhost";
    $dbUsername = "root";
    $dbPassword = "#e#KTEad%JPy8eYSCqd";
    $dbName = "coffeedtest";

    $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
    if(isset($_REQUEST["pay"])){
      $fullname = stripslashes($_REQUEST["fullname"]);
      $fullname = mysqli_real_escape_string($conn, $fullname);
      $mobile = stripslashes($_REQUEST["mobile"]);
      $mobile = mysqli_real_escape_string($conn, $mobile);
      $email = stripslashes($_REQUEST["email"]);
      $email = mysqli_real_escape_string($conn, $email);
      $address = stripslashes($_REQUEST["address"]);
      $address = mysqli_real_escape_string($conn, $address);
      $item = stripslashes($_REQUEST["item"]);
      $item = mysqli_real_escape_string($conn, $item);
      $total = stripslashes($_REQUEST["total"]);
      $total = mysqli_real_escape_string($conn, $total);

      $sql = "INSERT INTO Invoice(invoiceID, fullName, mobileNumber, emailAddress, homeAddress, itemName, grandTotal) VALUES('$fullname', '$mobile', '$email', '$address', '$item', '$total')";
      $result = mysqli_query($conn, $sql);
      if($result){
        echo "<div class='form'>
        <h3>Successful!</h3>
        <br/>Click here to <a href='invoice-form-DB.php'>Login</a> print receipt</div>";
      }
    }
    else{
  ?>

   <!--Header image-->
  <div class="headerimage">
    <img src="resources/2.jpeg">
  </div>
  <!--End of header image-->

  <!--Navigation bar-->
  <div class="navbar">
    <a href="index.html"> Home</a>
  <div class="dropdown">
    <button class="dropbtn"> Our Menu</button>
      <div class="dropdown-content">
         <a href="menu1.html"> All-Time Favourites</a>
         <a href="menu2.html"> Specials</a>
         <a href="menu3.html"> Cakes</a>
         <a href="menu4.html"> Beverages</a>
      </div>
  </div>
        <a href="order.html"> Order Now</a>
        <a href="feedback.html"> Feedback</a>
        <a href="contact.html"> Contact Us</a>
        <a href=""> Log In</a>
  </div>
  <!--End of navigation bar-->

    <!--Page header for feedback page-->
    <div class = "padding-y menu" id = "menu">
      <div class = "container">
        <div class = "title">
          <h2> Checkout</h2>
            <div class = "line center">
            <div></div>
            <div></div>
          </div>
        </div>
      </div>
    </div>
    <!--End of page header -->

    <!--Checkout section-->
    <div class="row">
    <div class="alright columns">
        <h3> Enter Your Details</h3>
        <div class="products">

        <form id="form" class="form" method="post">
            <div class="form-control">
                <label for="first">NAME</label>
                <p><input class="a" type="text" placeholder="Enter your full name" id="fullname" name="fullname" required/></p>
            </div>
            <div class="form-control">
                <label for="phone">MOBILE</label>
                <p><input class="b" type="tel" placeholder="(+60)1234567890" id="phone" minlength="10" name="mobile" required/></p>
            </div>
            <div class="form-control">
                <label for="email">EMAIL</label>
                <p><input class="c" type="email" placeholder="Enter your email address" id="email" name="email" required/></p>
            </div>
            <div class="form-control">
                <label for="phone">DELIVERY ADDRESS</label>
                <p><input class="d" type="text" placeholder="Lot 123, Street ABC, Postcode, District 123, City" id="del" name="address" required></p>
            </div>
            <p class="gnd">
                <label for="gen">PAYMENT OPTION</label>
                <p class="e">
                <input type='radio' name='radioBtn' name="payment" value="Credit Card" required id="cc">
                <label id="cc">Credit Card</label>
                <input type='radio' name='radioBtn' name="payment" value="Paypal" required id="pp">
                <label id="pp">PayPal</label>
                 <input type='radio' name='radioBtn' name="payment" value="Grabpay/Boost" required id="pay">
                <label id="pay">GrabPay/Boost</label>
                </p>
            </p>
						<div class="form-control">
                <label>Amount To Pay (RM)</label>
                <p><input class="a" type="text" placeholder="RM" name="total" required/></p>
								<label >Item</label>
                <p><input class="a" type="text" placeholder="Enter item(s)" name="item" required/></p>
            </div>
            <p class="tc"><input type="checkbox" required id="termsncond">
                <label for="termsncond">I have read the terms and conditions</label>
                <p>
                    <a href="order.html"><button class="butn rem" style="margin-top: 15px; " type="reset"> Cancel</button></a>
                    <a href=""><button class="butn check" style="margin-top: 15px; " type="submit" name="pay"> Pay</button></a>
                </p>
            </p>
        </form>
        </div>
    </div>

    <!--Display grand total-->
     <div class="cartcolumn">
        <div class="cart">
            <h3> Grand Total</h3>
            <div id="entire" name="item">Loading cart...</div>
            Total (incl. delivery) : <strong id="gtotal" name="total">RM 0 </strong>
            </div>
        </div>
    </div>
    <?php } ?>

<!--Javascripts used to aid the functions of the page-->
     <script type="text/template" id="shpcart">
        <% _.each(items, function (item) { %> <div class = "shopcart"> <h4> <%= item.name %> </h4>  <span class="label">
        <%= item.count %> item<% if(item.count > 1)
        {%>s
        <%}%> for RM<%= item.total %></span ></div>
        <% }); %>
    </script>

<script src="order.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.5.2/underscore-min.js'></script>

<!--End of checkout section-->
</body>

<footer>
    <div class="footer">
        <h2> &#169 MUGIWARA 2021</h2>
    </div>
</footer>

</html>
