<?php
  $servername = "localhost";
  $username = "root";
  $password = "#e#KTEad%JPy8eYSCqd";
  $dbname = "coffeedtest";

  $conn = mysqli_connect($servername, $username, $password, $dbname);
  if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
  }

  $sql = "INSERT INTO MyClient(
    firstName, lastName, mobileNumber, emailAddress, homeAddress)
    VALUES('Peter', 'Herraldson', 0145979319, 'lanchownima@example.com', 'Lot 666, Jln Goreng, Taman Awam, Miri 98000 Sarawak'
  )";

  if(mysqli_query($conn, $sql)){
    echo "New record created successfully";
  }
  else{
    "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

  mysqli_close($conn);
 ?>
