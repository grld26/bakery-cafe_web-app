<?php
  $servername = "localhost";
  $username = "root";
  $password = "#e#KTEad%JPy8eYSCqd";
  $dbname = "coffeedtest";

  $conn = mysqli_connect($servername, $username, $password, $dbname);

  if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
  }

  $sql = "CREATE TABLE MyItem(
    itemID INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    itemName VARCHAR(256) NOT NULL,
    itemPrice  FLOAT(6) NOT NULL
  )";

  if(mysqli_query($conn, $sql)){
    echo "Table MyClient created successfully";
  }
  else{
    echo "Error creating table: " . mysqli_error($conn);
  }

  mysqli_close($conn);
 ?>
